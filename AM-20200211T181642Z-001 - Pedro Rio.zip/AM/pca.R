## ---- spca_setup
library(ggplot2)
library(psych)
library(ggbiplot)
library(GGally)
library(knitr)
library(xtable)
library(kableExtra)
library(rrcov)
data_white <- read.csv("winequality-white.csv", sep = ";")
data <- rbind(data_white)
type <- rep(1, 4898)
data <- cbind(type, data)
data$quality <- factor(data$quality, ordered = TRUE, levels = c(3, 4, 5, 6, 7, 8, 9))

## ---- spca
spca <- prcomp(data[, 2:12], rank. = 6, scale = TRUE, retx = TRUE)
kable(summary(spca)$importance[, 1:6], format = "latex", booktabs = TRUE) %>%
  kable_styling(latex_options = "scale_down")

## ---- spca_loadings
loadings <- spca$rotation
kable(round(loadings, 3), format = "latex", booktabs = TRUE) %>%
  kable_styling(latex_options = "scale_down")

## ---- spca_scores
scores <- spca$x
# kable(round(scores, 3), format = "latex", booktabs = TRUE) %>%
#   kable_styling(latex_options = "scale_down")
scores <- scores[, 1:6]

## ---- spca_pairs
ggpairs(data.frame(scores), aes(colour = data$quality, alpha = 0.4))

## ---- spca_outlier_detection_plot
robpca <- PcaHubert(data[, 2:12], alpha = 1, k = 6, scale = TRUE)
plot(robpca, col = data$quality)

## ---- spca_outliers
outliers <- data.frame(!robpca@flag)
data <- data[!outliers,]
outliers <- data[!!outliers,]
outliers <- na.omit(outliers)

## ---- pairs_eda_outliers
ggpairs(outliers[, 2:13], aes(colour = outliers$quality, alpha = 0.4))

## ---- pairs_eda_data_without_outliers
ggpairs(data[, 2:13], aes(colour = data$quality, alpha = 0.4))

## ---- pairs_eda_scores_without_outliers
spca <- prcomp(data[, 2:12], rank. = 6, scale = TRUE, retx = TRUE)
scores <- spca$x
scores <- scores[, 1:6]
complete_scores <- scores
quality <- data$quality
complete_scores <- data.frame(complete_scores, quality)
ggpairs(complete_scores, aes(colour = complete_scores$quality, alpha = 0.4))
