## ---- setup_eda
library(ggplot2)
library(psych)
library(ggbiplot)
library(GGally)
library(knitr)
library(xtable)
library(kableExtra)
library(rrcov)
data_white <- read.csv("winequality-white.csv", sep = ";")
data <- rbind(data_white)
type <- rep(1, 4898)
data <- cbind(type, data)
data$quality <- factor(data$quality, ordered = TRUE, levels = c(3, 4, 5, 6, 7, 8, 9))

## ---- summary_eda
kable(summary(data[2:13]), format = "latex", booktabs = TRUE) %>%
  kable_styling(latex_options = "scale_down")

## ---- describe_eda
kable(describe(data[2:13]), format = "latex", booktabs = TRUE) %>%
  kable_styling(latex_options = "scale_down")

## ---- cov_eda
kable(round(cov(data[, 2:12]), 3), format = "latex", booktabs = TRUE) %>%
  kable_styling(latex_options = "scale_down")

## ---- cor_eda
kable(round(cor(data[, 2:12]), 3), format = "latex", booktabs = TRUE) %>%
  kable_styling(latex_options = "scale_down")

## ---- pairs_eda
ggpairs(data[, 2:13], aes(colour = data$quality, alpha = 0.4))

## ---- boxplots_eda
ggplot(data, aes(x = quality, y = residual.sugar, color = quality, group = quality)) +
  geom_boxplot() +
  labs(title = "Residual sugar per wine quality")
ggplot(data, aes(x = quality, y = fixed.acidity, color = quality, group = quality)) +
  geom_boxplot() +
  labs(title = "Fixed acidity per wine quality")
ggplot(data, aes(x = quality, y = volatile.acidity, color = quality, group = quality)) +
  geom_boxplot() +
  labs(title = "Volatile acidity per wine quality")
ggplot(data, aes(x = quality, y = citric.acid, color = quality, group = quality)) +
  geom_boxplot() +
  labs(title = "Citric acidity per wine quality")
ggplot(data, aes(x = quality, y = chlorides, color = quality, group = quality)) +
  geom_boxplot() +
  labs(title = "Chlorides per wine quality")
ggplot(data, aes(x = quality, y = density, color = quality, group = quality)) +
  geom_boxplot() +
  labs(title = "Density per wine quality")
ggplot(data, aes(x = quality, y = pH, color = quality, group = quality)) +
  geom_boxplot() +
  labs(title = "pH per wine quality")
ggplot(data, aes(x = quality, y = sulphates, color = quality, group = quality)) +
  geom_boxplot() +
  labs(title = "Sulphates per wine quality")
ggplot(data, aes(x = quality, y = alcohol, color = quality, group = quality)) +
  geom_boxplot() +
  labs(title = "Alcohol per wine quality")
ggplot(data,
       aes(x = quality, y = data$free.sulfur.dioxide, color = quality, group = quality)) +
  geom_boxplot() +
  labs(title = "Free sulfur dioxide per wine quality")
ggplot(data,
       aes(x = quality, y = data$total.sulfur.dioxide, color = quality, group = quality)) +
  geom_boxplot() +
  labs(title = "Total sulfur dioxide per wine quality")
ggplot(data,
       aes(x = quality)) +
  geom_bar(stat = "count", width = 0.7, fill = "steelblue") +
  theme_minimal() +
  labs(title = "White wines per quality")
