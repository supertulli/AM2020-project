## ---- c_setup
library(ggplot2)
library(psych)
library(ggbiplot)
library(GGally)
library(knitr)
library(xtable)
library(kableExtra)
library(vegan)
library(cluster)
library(rrcov)
library(fpc)
library(factoextra)
data_white <- read.csv("winequality-white.csv", sep = ";")
data <- rbind(data_white)
type <- rep(1, 4898)
data <- cbind(type, data)
data$quality <- factor(data$quality, ordered = TRUE, levels = c(3, 4, 5, 6, 7, 8, 9))
spca <- prcomp(data[, 2:12], scale = TRUE, retx = TRUE)
scores <- spca$x
scores <- scores[, 1:6]
robpca <- PcaHubert(data[, 2:12], alpha = 1, k = 6, scale = TRUE)
outliers <- data.frame(!robpca@flag)
data <- data[!outliers,]
outliers <- data[!!outliers,]
spca <- prcomp(data[, 2:12], rank. = 6, scale = TRUE, retx = TRUE)
scores <- spca$x
scores <- scores[, 1:6]

## ---- c_hierarchical_number
fviz_nbclust(scores, hcut, method = "silhouette")

## ---- c_single_average_weighted
wineQualitys <- agnes(scores[, 1:6], metric = "euclidean", method = "single")
pltree(wineQualitys, main = "", sub = "", xlab = "Data", labels = FALSE)
title("Single")
wineQualitya <- agnes(scores[, 1:6], metric = "euclidean", method = "average")
pltree(wineQualitya, main = "", sub = "", xlab = "Data", labels = FALSE)
title("Average")
wineQualitywe <- agnes(scores[, 1:6], metric = "euclidean", method = "weighted")
pltree(wineQualitywe, main = "", sub = "", xlab = "Data", labels = FALSE)
title("Weighted")

## ---- c_single_average_weighted_banners
bannerplot(wineQualitys, main = "Single Linkage",
           sub = c("       = Agglom coef", round(wineQualitys$ac, digits = 2)))
bannerplot(wineQualitya, main = "Average Linkage",
           sub = c("       = Agglom coef", round(wineQualitya$ac, digits = 2)))
bannerplot(wineQualitywe, main = "Weighted Average Linkage",
           sub = c("       = Agglom coef", round(wineQualitywe$ac, digits = 2)))

## ---- c_complete
wineQualityc <- agnes(scores[, 1:6], metric = "euclidean", method = "complete")
pltree(wineQualityc, main = "", sub = "", xlab = "Data", labels = FALSE)
title("Complete")

## ---- c_complete_banner
bannerplot(wineQualityc, main = "Complete Linkage",
           sub = c("       = Agglom coef", round(wineQualityc$ac, digits = 2)))

## ---- c_ward
wineQualitywa <- agnes(scores[, 1:6], metric = "euclidean", method = "ward")
pltree(wineQualitywa, main = "", sub = "", xlab = "Data", labels = FALSE)
title("Ward")

## ---- c_ward_banner
bannerplot(wineQualitywa, main = "Ward method",
           sub = c("       = Agglom coef", round(wineQualitywa$ac, digits = 2)))

## ---- c_ward_cuts
distance <- dist(scores, method = "euclidean")
fit <- hclust(distance, method = "ward.D2")
plot(fit, labels = FALSE)
rect.hclust(fit, k = 2, border = "steelblue")

## ---- c_ward_clusters
groups <- cutree(fit, k = 2)
clusplot(scores, groups, color = TRUE, shade = TRUE, labels = 4, lines = 0, stand = TRUE,
         s.x.2d = list(x = scores[, c(1, 2)], labs = rownames(scores),
                       var.dec = sum(summary(spca)$importance[2, c(1, 2)])))

## ---- c_k_means_number
fviz_nbclust(scores, kmeans, method = "silhouette")

## ---- c_k_means
k2 <- kmeans(scores, centers = 2)
k2clu <- data.frame(table(k2$cluster))
k2cen <- data.frame(k2$centers)
k2cen <- data.frame(Cluster = seq.int(nrow(k2cen)), k2cen)
colnames(k2clu) <- c("Cluster", "Frequency")
k2info <- data.frame(k2clu[, 1:2], k2cen[, 2:7])
kable(k2info, format = "latex", booktabs = TRUE)

## ---- c_k_means_plots
k2 <- kmeans(scores, centers = 2)
clusplot(scores, k2$cluster, color = TRUE, shade = TRUE, labels = 4, lines = 0, stand = TRUE,
         s.x.2d = list(x = scores[, c(1, 2)], labs = rownames(scores),
                       var.dec = sum(summary(spca)$importance[2, c(1, 2)])))

## ---- c_k_medoids_number
fviz_nbclust(scores, pam, method = "silhouette")

## ---- c_k_medoids
p2 <- pam(scores, 2)

## ---- c_k_medoids_plots
clusplot(scores, p2$clustering, color = TRUE, shade = TRUE, labels = 4, lines = 0, stand = TRUE,
         s.x.2d = list(x = scores[, c(1, 2)], labs = rownames(scores),
                       var.dec = sum(summary(spca)$importance[2, c(1, 2)])))
